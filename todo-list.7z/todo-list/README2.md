I did the following thing to setup this todo-list project 

1.)Created the react app with name todo-list app
2.)Added the Bootscript and jquery using npm cmd
3.)Added the redux to manage the task data among the component
4.)Added the fontAwesome icon for edit and delete icon
5.)Added the formik and yup for form validation
6.)Added the moment for formating the time
7.)Added the datePicker for date
8.)Added the dataTable for listing the task on Home page


#Home page link
http://localhost:3000/

#Edit page link
http://localhost:3000/edit/1



<!-- Thank you so much sir for giving me such interesting task I really enjoyed this task -->